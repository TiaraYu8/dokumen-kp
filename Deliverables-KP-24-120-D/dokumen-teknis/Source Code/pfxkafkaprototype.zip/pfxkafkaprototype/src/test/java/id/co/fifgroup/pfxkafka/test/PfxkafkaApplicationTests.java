package id.co.fifgroup.pfxkafka.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PfxkafkaApplicationTests {

	@Test
	void contextLoads() {
	}

}
