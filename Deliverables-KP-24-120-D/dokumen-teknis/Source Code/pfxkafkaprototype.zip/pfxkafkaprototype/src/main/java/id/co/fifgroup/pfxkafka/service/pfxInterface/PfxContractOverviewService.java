package id.co.fifgroup.pfxkafka.service.pfxInterface;

import id.co.fifgroup.pfxkafka.service.PfxResultProcessorServiceInterface;

public interface PfxContractOverviewService extends PfxResultProcessorServiceInterface {
}
