package id.co.fifgroup.pfxkafka.common.consts;

public class KTableLabelConstants {
    public static final String KTABLE_LABEL_SINGLE_OBJECT_DATA = "pf-single-object-data";
    public static final String KTABLE_LABEL_ARRAY_OBJECT_DATA = "pf-array-object-data";
    private KTableLabelConstants() {}
}
