## General Sequence Diagram

### Splitting pefindo data by field type (ARRAY_OBJECT / SINGLE_OBJECT)
![diagram1](./image/process%20single%20or%20array%20data.png)

### Topology processing kafka's data stream
![diagram2](./image/topology%20processing%20kafka%20stream.png)

### Processing SINGLE_OBJECT / ARRAY_OBJECT data stream
![diagram3](./image/process%20single%20or%20array%20data.png)
